import{a as t}from"../chunks/P3ZA7ReR.js";export{t as start};
